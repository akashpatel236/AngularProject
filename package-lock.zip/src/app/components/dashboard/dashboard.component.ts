import { Component, OnInit } from '@angular/core';
import { QuestionService } from 'src/app/services/question/question.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private questionService: QuestionService) { }

  data = [
    // {
    //   id: 1,
    //   question: 'what',
    //   askedBy: 'defg',
    //   answers: [
    //     { 
    //       votes: 10,
    //       answeredOn: new Date(),
    //       answerBy: 'def',
    //       answer: 'fcdsfhsdhfidshfcdsjnkjdsnfjknsdkjcnsdkjcnksdjnckjsdnckjsdnckjsdnckjsdncksdnkdsjcnksdnksn'
    //     },
    //     { 
    //       votes: 10,
    //       answeredOn: new Date(),
    //       answerBy: 'ghi',
    //       answer: 'fcdsfhsdhfidshfcdsjnkjdsnfjknsdkjcnsdkjcnksdjnckjsdnckjsdnckjsdnckjsdncksdnkdsjcnksdnksn'
    //     }
    //   ],
    //   askedOn: new Date(),
    //   domain: ['qwe', '123']
    // },
    // {
    //   id: 2,
    //   question: 'what',
    //   askedBy: 'defg',
    //   answers: [
    //     { 
    //       votes: 10,
    //       answeredOn: new Date(),
    //       answerBy: 'def',
    //       answer: 'fcdsfhsdhfidshfcdsjnkjdsnfjknsdkjcnsdkjcnksdjnckjsdnckjsdnckjsdnckjsdncksdnkdsjcnksdnksn'
    //     },
    //     { 
    //       votes: 10,
    //       answeredOn: new Date(),
    //       answerBy: 'ghi',
    //       answer: 'fcdsfhsdhfidshfcdsjnkjdsnfjknsdkjcnsdkjcnksdjnckjsdnckjsdnckjsdnckjsdncksdnkdsjcnksdnksn'
    //     }
    //   ],
    //   askedOn: new Date(),
    //   domain: ['qwe', '123']
    // },
    // {
    //   id: 3,
    //   question: 'what',
    //   askedBy: 'defg',
    //   answers: [
    //     { 
    //       votes: 10,
    //       answeredOn: new Date(),
    //       answerBy: 'def',
    //       answer: 'fcdsfhsdhfidshfcdsjnkjdsnfjknsdkjcnsdkjcnksdjnckjsdnckjsdnckjsdnckjsdncksdnkdsjcnksdnksn'
    //     },
    //     { 
    //       votes: 10,
    //       answeredOn: new Date(),
    //       answerBy: 'ghi',
    //       answer: 'fcdsfhsdhfidshfcdsjnkjdsnfjknsdkjcnsdkjcnksdjnckjsdnckjsdnckjsdnckjsdncksdnkdsjcnksdnksn'
    //     }
    //   ],
    //   askedOn: new Date(),
    //   domain: ['qwe', '123']
    // }
  ]

  ngOnInit() {
    this.questionService.getQuestions().subscribe((resp: any) => {
      this.data = resp;
    });
  }

}
