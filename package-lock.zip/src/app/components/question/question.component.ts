import { Component, OnInit } from '@angular/core';
import { Route } from '@angular/compiler/src/core';
import { Router, ActivatedRoute } from '@angular/router';
import { QuestionService } from 'src/app/services/question/question.service';

@Component({
  selector: 'app-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.css']
})
export class QuestionComponent implements OnInit {

  que: any;
  answer: string;

  constructor(
    private route: ActivatedRoute,
    private questionService: QuestionService) { }

  ngOnInit() {
      this.route.params.subscribe((params: any) => {
        this.questionService.getQuestion( params['id']).subscribe((que: any) => {
          this.que = que;
        });
      });
  }

  submitAnswer() {
    const data = {
      id: this.que.id,
        answer: this.answer,
        answerBy: 'abc'
    };
    this.questionService.submitAnswer(data).subscribe((resp: any) => {
      alert('answer submitter');
      this.que = resp;
    });
  }

}
